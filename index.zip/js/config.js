window._config = {
    cognito: {
        userPoolId: 'us-east-1_W3iE8eUaB', // e.g. us-east-2_uXboG5pAb
        userPoolClientId: '783rlmf2k93k960ku4aqp20sdq', // e.g. 25ddkmj4v6hfsfvruhpfi7n4hv
        region: 'us-east-1' // e.g. us-east-2
    },
    api: {
        invokeUrl: '' // e.g. https://rc7nyt4tql.execute-api.us-west-2.amazonaws.com/prod',
    }
};
